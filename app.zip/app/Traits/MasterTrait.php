<?php 

namespace App\Traits;

trait MasterTrait{
    // protected $connection = "master";
}