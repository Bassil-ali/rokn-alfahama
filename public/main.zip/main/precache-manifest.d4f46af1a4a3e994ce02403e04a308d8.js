self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5c9ecf789e718b208bca",
    "url": "/main/css/chunk-2a9fa0af-chunk.css"
  },
  {
    "revision": "a0f38554c9943dd01ce4",
    "url": "/main/css/chunk-79992c5a-chunk.css"
  },
  {
    "revision": "df3d9d5a2ffd63b63b13",
    "url": "/main/css/chunk-94033094-chunk.css"
  },
  {
    "revision": "143f6094dc9b02ef221c",
    "url": "/main/css/chunk-9eb2af90-chunk.css"
  },
  {
    "revision": "1bd1da0a0d9904e36995",
    "url": "/main/css/chunk-common-chunk.css"
  },
  {
    "revision": "cad0545f1de59042271c",
    "url": "/main/css/chunk-d31cb614-chunk.css"
  },
  {
    "revision": "624d1b76d731f3a3aa3f",
    "url": "/main/css/chunk-dd8a53c0-chunk.css"
  },
  {
    "revision": "2e397ce69d4bf02e9af2",
    "url": "/main/css/chunk-vendors-chunk.css"
  },
  {
    "revision": "2d80533d5ff04674843f",
    "url": "/main/css/dashboard.css"
  },
  {
    "revision": "cb40222236bbaf8db59a",
    "url": "/main/css/index.css"
  },
  {
    "revision": "9c1a27a0bad58f7643bcb5f1fb286b0d",
    "url": "/main/dashboard.html"
  },
  {
    "revision": "1ba2ae710d927f13d483fd5d1e548c9b",
    "url": "/main/favicon1.ico"
  },
  {
    "revision": "6750752c0a6b08565976227cd8bad24a",
    "url": "/main/fonts/DINNextLTArabic-Light.6750752c.woff"
  },
  {
    "revision": "a1019b6ebbeb8918d62f38cb652910dc",
    "url": "/main/fonts/DINNextLTArabic-Light.a1019b6e.woff2"
  },
  {
    "revision": "4384e8b1f626a925d4b1b34879f4e9a7",
    "url": "/main/fonts/DINNextLTArabic-Medium.4384e8b1.woff2"
  },
  {
    "revision": "7dc3542af6f06975ae4d9963c66c33b5",
    "url": "/main/fonts/DINNextLTArabic-Medium.7dc3542a.woff"
  },
  {
    "revision": "3dfacbefae4998a6747a896bd17349b1",
    "url": "/main/fonts/DINNextLTArabic-Regular.3dfacbef.woff"
  },
  {
    "revision": "64e982d0718dbcefdd3383ec6a438d2f",
    "url": "/main/fonts/DINNextLTArabic-Regular.64e982d0.woff2"
  },
  {
    "revision": "0bfc243407d6fcfda582970f4a25eef6",
    "url": "/main/fonts/DINNextLTW23-Bold2.0bfc2434.woff"
  },
  {
    "revision": "4b7f514029710e6c7d3e87e5aab34d1d",
    "url": "/main/fonts/DINNextLTW23-Bold2.4b7f5140.woff2"
  },
  {
    "revision": "bad01a8965b8562e2e7447fe04723acd",
    "url": "/main/fonts/bootstrap-icons.bad01a89.woff"
  },
  {
    "revision": "be57951d47bc6b1635653a38cbdf30fd",
    "url": "/main/fonts/bootstrap-icons.be57951d.woff2"
  },
  {
    "revision": "099a9556e1a63ece24f8a99859c94c7d",
    "url": "/main/fonts/fa-brands-400.099a9556.woff"
  },
  {
    "revision": "1a575a4138e5f366474f0e7c5bd614a5",
    "url": "/main/fonts/fa-brands-400.1a575a41.woff"
  },
  {
    "revision": "30cc681d4487d2f561035ba24a68c629",
    "url": "/main/fonts/fa-brands-400.30cc681d.eot"
  },
  {
    "revision": "3b89dd103490708d19a95adcae52210e",
    "url": "/main/fonts/fa-brands-400.3b89dd10.ttf"
  },
  {
    "revision": "513aa607d398efaccc559916c3431403",
    "url": "/main/fonts/fa-brands-400.513aa607.ttf"
  },
  {
    "revision": "592643a83b8541edc52063d84c468700",
    "url": "/main/fonts/fa-brands-400.592643a8.eot"
  },
  {
    "revision": "ed311c7a0ade9a75bb3ebf5a7670f31d",
    "url": "/main/fonts/fa-brands-400.ed311c7a.woff2"
  },
  {
    "revision": "f7307680c7fe85959f3ecf122493ea7d",
    "url": "/main/fonts/fa-brands-400.f7307680.woff2"
  },
  {
    "revision": "1f77739ca9ff2188b539c36f30ffa2be",
    "url": "/main/fonts/fa-regular-400.1f77739c.ttf"
  },
  {
    "revision": "7124eb50fc8227c78269f2d995637ff5",
    "url": "/main/fonts/fa-regular-400.7124eb50.woff"
  },
  {
    "revision": "7630483dd4b0c48639d2ac54a894b450",
    "url": "/main/fonts/fa-regular-400.7630483d.eot"
  },
  {
    "revision": "766913e6c0088ab8c9f73e18b4127bc4",
    "url": "/main/fonts/fa-regular-400.766913e6.ttf"
  },
  {
    "revision": "b0e2db3b634d1bc3928e127458d993d8",
    "url": "/main/fonts/fa-regular-400.b0e2db3b.eot"
  },
  {
    "revision": "b91d376b8d7646d671cd820950d5f7f1",
    "url": "/main/fonts/fa-regular-400.b91d376b.woff2"
  },
  {
    "revision": "d1d7e3b4c219fde0f7376c6facfd7149",
    "url": "/main/fonts/fa-regular-400.d1d7e3b4.woff"
  },
  {
    "revision": "f0f8230116992e521526097a28f54066",
    "url": "/main/fonts/fa-regular-400.f0f82301.woff2"
  },
  {
    "revision": "0c6bfc668a72935760178f91327aed3a",
    "url": "/main/fonts/fa-solid-900.0c6bfc66.eot"
  },
  {
    "revision": "1042e8ca1ce821518a2d3e7055410839",
    "url": "/main/fonts/fa-solid-900.1042e8ca.eot"
  },
  {
    "revision": "605ed7926cf39a2ad5ec2d1f9d391d3d",
    "url": "/main/fonts/fa-solid-900.605ed792.ttf"
  },
  {
    "revision": "9fe5a17c8ab036d20e6c5ba3fd2ac511",
    "url": "/main/fonts/fa-solid-900.9fe5a17c.woff"
  },
  {
    "revision": "b9625119ce4300f0ef890a8f3234c773",
    "url": "/main/fonts/fa-solid-900.b9625119.ttf"
  },
  {
    "revision": "d745348d289b149026921f197929a893",
    "url": "/main/fonts/fa-solid-900.d745348d.woff"
  },
  {
    "revision": "d824df7eb2e268626a2dd9a6a741ac4e",
    "url": "/main/fonts/fa-solid-900.d824df7e.woff2"
  },
  {
    "revision": "e8a427e15cc502bef99cfd722b37ea98",
    "url": "/main/fonts/fa-solid-900.e8a427e1.woff2"
  },
  {
    "revision": "02042f70285174c87cbda135120f35dc",
    "url": "/main/img/0001.02042f70.jpg"
  },
  {
    "revision": "864104665f836029d1823775d1c6441f",
    "url": "/main/img/001-heart.86410466.svg"
  },
  {
    "revision": "40512ccf48572f1c89e9f46db056a520",
    "url": "/main/img/002-instagram.40512ccf.svg"
  },
  {
    "revision": "a59819be325c0de386ad2e74d28ca0a1",
    "url": "/main/img/003-facebook.a59819be.svg"
  },
  {
    "revision": "713984134254018c0afee18601ce6236",
    "url": "/main/img/006-close-envelope.71398413.svg"
  },
  {
    "revision": "68d281c3673bf534fdc355875a2e5b6b",
    "url": "/main/img/404-bottom.68d281c3.svg"
  },
  {
    "revision": "0da3bb447f551373dda663b39d59d309",
    "url": "/main/img/404-top.0da3bb44.svg"
  },
  {
    "revision": "ec930bc5db1dbe97879c53560bfd1fc0",
    "url": "/main/img/54c5989ec7bc8b192c60f9e9a0dae937.ec930bc5.jpg"
  },
  {
    "revision": "12a654d490dedbe5a16e0300ec745d3d",
    "url": "/main/img/Image-21.12a654d4.jpg"
  },
  {
    "revision": "d8aef92a576f8f3fdb68a325a646c84c",
    "url": "/main/img/OBJECTS.d8aef92a.png"
  },
  {
    "revision": "7ab5adb7226fda1e9f027443d92608b3",
    "url": "/main/img/Send-gift-bro.7ab5adb7.png"
  },
  {
    "revision": "e8899ee79926791088ea89b0d5236d82",
    "url": "/main/img/Union-43.e8899ee7.png"
  },
  {
    "revision": "2b21e3560049792351f17332d2d08ca1",
    "url": "/main/img/address.2b21e356.svg"
  },
  {
    "revision": "5f0b7871e6adf56805968e18f892bd93",
    "url": "/main/img/banner01.5f0b7871.jpg"
  },
  {
    "revision": "0387f98507331fe32d08bc266888433b",
    "url": "/main/img/banner02.0387f985.jpg"
  },
  {
    "revision": "48d2e2cb10522e25f53270f4acfecc2a",
    "url": "/main/img/bg-footer.48d2e2cb.jpg"
  },
  {
    "revision": "5e1dd7eaa9f41dbe6085eb49c05a8c90",
    "url": "/main/img/ce9ef2dfec7fc7b38213892c7d788a78.5e1dd7ea.jpg"
  },
  {
    "revision": "0da13833688e583219867e6d4c1de668",
    "url": "/main/img/col.0da13833.svg"
  },
  {
    "revision": "c2b69af0db1fe697051202297fdc5cb0",
    "url": "/main/img/contact.c2b69af0.svg"
  },
  {
    "revision": "df2bf958efe1ed4e25ba02996c6b413e",
    "url": "/main/img/d803777492c0fe71db41dcceff187467.df2bf958.jpg"
  },
  {
    "revision": "f35acaa86f78c40fe447f25b9caac142",
    "url": "/main/img/del.f35acaa8.svg"
  },
  {
    "revision": "a0a33179aefb71021fde7fa3dcb2cd7d",
    "url": "/main/img/delete-red.a0a33179.svg"
  },
  {
    "revision": "bb3c8ea38bb8bfc141b4ff23c16792bb",
    "url": "/main/img/delete.bb3c8ea3.svg"
  },
  {
    "revision": "7b7c5c58f93aa0fa78913eea2a0d7908",
    "url": "/main/img/discount.7b7c5c58.svg"
  },
  {
    "revision": "bdc77dd80da9a2239cc4463bedc92a74",
    "url": "/main/img/edit.bdc77dd8.svg"
  },
  {
    "revision": "1d5619cd804367cefe6da2d79289218a",
    "url": "/main/img/fa-brands-400.1d5619cd.svg"
  },
  {
    "revision": "ba7ed552362f64d30f6d844974d89114",
    "url": "/main/img/fa-brands-400.ba7ed552.svg"
  },
  {
    "revision": "0bb428459c8ecfa61b22a03def1706e6",
    "url": "/main/img/fa-regular-400.0bb42845.svg"
  },
  {
    "revision": "c5d109be8edd3de0f60eb472bd9ef691",
    "url": "/main/img/fa-regular-400.c5d109be.svg"
  },
  {
    "revision": "376c1f97f6553dea1ca9b3f9081889bd",
    "url": "/main/img/fa-solid-900.376c1f97.svg"
  },
  {
    "revision": "37bc7099f6f1ba80236164f22e905837",
    "url": "/main/img/fa-solid-900.37bc7099.svg"
  },
  {
    "revision": "f5dac98334077622eb0cd1433f433212",
    "url": "/main/img/false.f5dac983.svg"
  },
  {
    "revision": "88dab1363af705444ecb3f77f54c7dc3",
    "url": "/main/img/faq.88dab136.svg"
  },
  {
    "revision": "9c96e0ed7093c095fd33870329282962",
    "url": "/main/img/flags.9c96e0ed.9c96e0ed.png"
  },
  {
    "revision": "9394306fe632a68a92e1b402af5cb110",
    "url": "/main/img/grid.9394306f.svg"
  },
  {
    "revision": "89dce6790e9f424ea44daef4fb5ee542",
    "url": "/main/img/headphones.89dce679.svg"
  },
  {
    "revision": "1763bbbb3e66ac930e3ac0486c3306b8",
    "url": "/main/img/hearts-fill.1763bbbb.svg"
  },
  {
    "revision": "94e0488138eeeabe99e33669693de963",
    "url": "/main/img/hearts.94e04881.svg"
  },
  {
    "revision": "eb9a0f9324bd98ec021335af4676184a",
    "url": "/main/img/history.eb9a0f93.svg"
  },
  {
    "revision": "aeb419f24ab7c310d64154aea5ff5632",
    "url": "/main/img/logo-w.aeb419f2.svg"
  },
  {
    "revision": "6ff2806ebd8b06099e970892785459d7",
    "url": "/main/img/logo.6ff2806e.png"
  },
  {
    "revision": "c0e66c64afb8af130e6ff99ea21a8160",
    "url": "/main/img/logout.c0e66c64.svg"
  },
  {
    "revision": "48f77b5c257fe5ce4f04e0a61c844e05",
    "url": "/main/img/pin-add.48f77b5c.svg"
  },
  {
    "revision": "c73e03224c8b016b31d912e4f993abdb",
    "url": "/main/img/shipped.c73e0322.svg"
  },
  {
    "revision": "c27f130cddd71954c0142265e5d89808",
    "url": "/main/img/shopping-cart-2.c27f130c.svg"
  },
  {
    "revision": "635e6f0e47033d7c218c9a6419836470",
    "url": "/main/img/shopping-cart.635e6f0e.svg"
  },
  {
    "revision": "7c69b1b216e6c7da54e8c52bb1742a27",
    "url": "/main/img/sucess.7c69b1b2.svg"
  },
  {
    "revision": "c8824f334107c92fe549d53027eb1fab",
    "url": "/main/img/undraw_empty_cart_co35.c8824f33.svg"
  },
  {
    "revision": "728954db3eff682574e4e6b0d8b7a3fb",
    "url": "/main/img/user-icon.728954db.svg"
  },
  {
    "revision": "0608d5e29f91e26695a98f085bc3aa2d",
    "url": "/main/img/user.0608d5e2.svg"
  },
  {
    "revision": "34de20d3fb5d89a622bdf4c60febb9c0",
    "url": "/main/index.html"
  },
  {
    "url": "/main/js/chunk-2a9fa0af.abe.5c9ecf789e718b208bca.min.js"
  },
  {
    "url": "/main/js/chunk-79992c5a.8ba.a0f38554c9943dd01ce4.min.js"
  },
  {
    "url": "/main/js/chunk-94033094.c4d.df3d9d5a2ffd63b63b13.min.js"
  },
  {
    "url": "/main/js/chunk-9eb2af90.626.143f6094dc9b02ef221c.min.js"
  },
  {
    "url": "/main/js/chunk-common.725.1bd1da0a0d9904e36995.min.js"
  },
  {
    "url": "/main/js/chunk-d31cb614.3ff.cad0545f1de59042271c.min.js"
  },
  {
    "url": "/main/js/chunk-dd8a53c0.f85.624d1b76d731f3a3aa3f.min.js"
  },
  {
    "url": "/main/js/chunk-vendors.7fd.2e397ce69d4bf02e9af2.min.js"
  },
  {
    "url": "/main/js/dashboard.a45.2d80533d5ff04674843f.min.js"
  },
  {
    "url": "/main/js/index.d96.cb40222236bbaf8db59a.min.js"
  },
  {
    "revision": "75cee0c9ead85d8d49643a2ecf8bf7f9",
    "url": "/main/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/main/robots.txt"
  }
]);